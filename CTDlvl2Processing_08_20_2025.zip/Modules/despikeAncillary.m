function despikeAncillary(D);


keyboard